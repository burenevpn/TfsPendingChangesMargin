TfsPendingChangesMargin
=======================

A Visual Studio extension to display TFS Pending Changes on the margin of the current file.
<br/>You can grab the extension from [the Visual Studio Gallery](http://visualstudiogallery.msdn.microsoft.com/25273ec2-fbe2-447a-8692-5ac3c35f7006, "TfsPendingChangesMargin on the Visual Studio Gallery").

![Screenshot](/Screenshots/screenshot1.png)

![Screenshot](/Screenshots/screenshot2.png)&nbsp;&nbsp;
![Screenshot](/Screenshots/screenshot3.png)
